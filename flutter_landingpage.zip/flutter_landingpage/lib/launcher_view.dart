import 'package:flutter/material.dart';

class LauncherPage extends StatefulWidget {
  @override
  _LauncherPageState createState() => new _LauncherPageState();
}

class _LauncherPageState extends State<LauncherPage> {

  @override
  Widget build(BuildContext context) {
    return new Scaffold();
  }
}