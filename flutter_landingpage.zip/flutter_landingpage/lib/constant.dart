import 'package:flutter/material.dart';

class landingpage {
  static Color green        = Color.fromARGB(255, 69, 170, 74);
  static Color grey         = Color.fromARGB(255, 242, 242, 242);
  static Color grey200      = Color.fromARGB(200, 242, 242, 242);
  static Color menuUtama     = Color(0xffe99e1e);
}